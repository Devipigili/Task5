# Task 5: SQL JOINs

## Objective
Combine data from multiple tables using various types of JOINs.

## Tables Used
- Customers
- Orders

## JOINs Demonstrated
- INNER JOIN
- LEFT JOIN
- RIGHT JOIN
- FULL OUTER JOIN (emulated using UNION)

## Output
Queries return customer names along with their ordered products.